import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Main {
    private static InventoryManager manager = new InventoryManager();
    private static DefaultListModel<String> listModel = new DefaultListModel<>();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Inventory Tracker");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JTextField nameField = new JTextField(10);
        JTextField quantityField = new JTextField(5);
        JButton addButton = new JButton("Add Item");

        JList<String> itemList = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(itemList);

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Item Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Quantity:"));
        inputPanel.add(quantityField);
        inputPanel.add(addButton);

        frame.getContentPane().add(inputPanel, BorderLayout.NORTH);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String qtyText = quantityField.getText().trim();
                if (!name.isEmpty() && !qtyText.isEmpty()) {
                    try {
                        int qty = Integer.parseInt(qtyText);
                        InventoryItem item = new InventoryItem(name, qty);
                        manager.addItem(item);
                        listModel.addElement(item.toString());
                        nameField.setText("");
                        quantityField.setText("");
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Enter a valid number for quantity.");
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please fill both fields.");
                }
            }
        });

        frame.setVisible(true);
    }
}