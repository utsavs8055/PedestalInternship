import java.util.ArrayList;

public class InventoryManager {
    private ArrayList<InventoryItem> items;

    public InventoryManager() {
        items = new ArrayList<>();
    }

    public void addItem(InventoryItem item) {
        items.add(item);
    }

    public ArrayList<InventoryItem> getAllItems() {
        return items;
    }
}